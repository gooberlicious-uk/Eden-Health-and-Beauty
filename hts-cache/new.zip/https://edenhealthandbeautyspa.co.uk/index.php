<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,300;0,500;1,300;1,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="/application/themes/eden/vendor/bootstrap-3.4.1-dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/application/themes/eden/css/application.css">

    
<title>Welcome :: Eden Health &amp; Beauty Spa</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Eden Health &amp; Beauty Spa is a friendly beauty salon in the centre of Cheltenham."/>
<meta name="generator" content="concrete5 - 8.5.4"/>
<meta name="msapplication-TileImage" content="https://edenhealthandbeautyspa.co.uk/application/files/3215/9792/0509/windows.png"/>
<link rel="shortcut icon" href="https://edenhealthandbeautyspa.co.uk/application/files/1715/9792/0507/favicon.ico" type="image/x-icon"/>
<link rel="icon" href="https://edenhealthandbeautyspa.co.uk/application/files/1715/9792/0507/favicon.ico" type="image/x-icon"/>
<link rel="apple-touch-icon" href="https://edenhealthandbeautyspa.co.uk/application/files/3815/9792/0508/iphone.png"/>
<link rel="canonical" href="https://edenhealthandbeautyspa.co.uk/">
<script type="text/javascript">
    var CCM_DISPATCHER_FILENAME = "/index.php";
    var CCM_CID = 1;
    var CCM_EDIT_MODE = false;
    var CCM_ARRANGE_MODE = false;
    var CCM_IMAGE_PATH = "/concrete/images";
    var CCM_TOOLS_PATH = "/index.php/tools/required";
    var CCM_APPLICATION_URL = "https://edenhealthandbeautyspa.co.uk";
    var CCM_REL = "";
    var CCM_ACTIVE_LOCALE = "en_GB";
</script>

<script type="text/javascript" src="/concrete/js/jquery.js?ccm_nocache=d846f33d9148b37e63b22ff9a7339155be77a7f9"></script>
<!--[if lt IE 9]><script type="text/javascript" src="/concrete/js/ie/html5-shiv.js?ccm_nocache=d846f33d9148b37e63b22ff9a7339155be77a7f9"></script><![endif]-->
<!--[if lt IE 9]><script type="text/javascript" src="/concrete/js/ie/respond.js?ccm_nocache=d846f33d9148b37e63b22ff9a7339155be77a7f9"></script><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta property="og:title" content="Eden Health & Beauty Spa - Welcome">
    <meta property="og:description" content="Eden Health & Beauty Spa is a friendly beauty salon in the centre of Cheltenham.">
    <meta property="og:image" content="https://edenhealthandbeautyspa.co.uk//application/themes/eden/img/og-image.jpg">
    <meta property="og:url" content="https://edenhealthandbeautyspa.co.uk/">
    <meta name="twitter:card" content="summary_large_image">
    
    <script>
        if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
            var msViewportStyle = document.createElement('style');
            msViewportStyle.appendChild(
                document.createTextNode(
                    '@-ms-viewport{width:auto!important}'
                )
            );
            document.querySelector('head').appendChild(msViewportStyle);
        }
    </script>

</head>
<body>

<div class="ccm-page ccm-page-id-1 page-type-hero-page page-template-hero" id="top">

<div class="hidden-xs hidden-sm header-socials">
    

    

    <a href="https://www.facebook.com/edenhealthandbeauty/" target="_blank"><svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square" class="svg-inline--fa fa-facebook-square fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z"></path></svg></a>



    

    <a href="https://www.instagram.com/edenhealthandbeauty/" target="_blank"><svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="instagram-square" class="svg-inline--fa fa-instagram-square fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M224,202.66A53.34,53.34,0,1,0,277.36,256,53.38,53.38,0,0,0,224,202.66Zm124.71-41a54,54,0,0,0-30.41-30.41c-21-8.29-71-6.43-94.3-6.43s-73.25-1.93-94.31,6.43a54,54,0,0,0-30.41,30.41c-8.28,21-6.43,71.05-6.43,94.33S91,329.26,99.32,350.33a54,54,0,0,0,30.41,30.41c21,8.29,71,6.43,94.31,6.43s73.24,1.93,94.3-6.43a54,54,0,0,0,30.41-30.41c8.35-21,6.43-71.05,6.43-94.33S357.1,182.74,348.75,161.67ZM224,338a82,82,0,1,1,82-82A81.9,81.9,0,0,1,224,338Zm85.38-148.3a19.14,19.14,0,1,1,19.13-19.14A19.1,19.1,0,0,1,309.42,189.74ZM400,32H48A48,48,0,0,0,0,80V432a48,48,0,0,0,48,48H400a48,48,0,0,0,48-48V80A48,48,0,0,0,400,32ZM382.88,322c-1.29,25.63-7.14,48.34-25.85,67s-41.4,24.63-67,25.85c-26.41,1.49-105.59,1.49-132,0-25.63-1.29-48.26-7.15-67-25.85s-24.63-41.42-25.85-67c-1.49-26.42-1.49-105.61,0-132,1.29-25.63,7.07-48.34,25.85-67s41.47-24.56,67-25.78c26.41-1.49,105.59-1.49,132,0,25.63,1.29,48.33,7.15,67,25.85s24.63,41.42,25.85,67.05C384.37,216.44,384.37,295.56,382.88,322Z"></path></svg></a>

</div>

<nav class="nav-mobile-nav visible-xs-block visible-sm-block">
    <div class="nav-toggle">
        <span class="toggle-open"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="black" width="18px" height="18px"><path d="M0 0h24v24H0z" fill="none"/><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg></span>
        <span class="toggle-close"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="black" width="18px" height="18px"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg></span>
    </div>
    <div class="mobile-nav-position">
        <div class="mobile-nav-links">
            

    <ul class="nav"><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us" target="_self" class="">About Us</a><ul><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us/eden-story" target="_self" class="">The Eden Story</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us/salon" target="_self" class="">Our Salon</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us/eden-team" target="_self" class="">The Eden Team</a></li></ul></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments" target="_self" class="">Products &amp; Treatments</a><ul><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments/our-products" target="_self" class="">Our Products</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments/our-treatments" target="_self" class="">Our Treatments</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments/book-treatment" target="_self" class="">Book a Treatment</a></li></ul></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/connect" target="_self" class="">Connect</a><ul><li class=""><a href="https://edenhealthandbeautyspa.co.uk/connect/contact-us" target="_self" class="">Contact Us</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/connect/eden-newsletter" target="_self" class="">Eden Newsletter</a></li></ul></li></ul>
        </div>
    </div>
</nav>

<header class="container">
    <div class="row">
        <div class="col-xs-12 header-logo">
            

    <a href="https://www.edenhealthandbeautyspa.co.uk/" ><img src="/application/files/7315/9468/7804/Eden-logo-2020.svg" alt="" class="ccm-svg ccm-image-block img-responsive bID-362"></a>
        </div>
    </div>
</header>

<nav class="nav-site-nav container hidden-xs hidden-sm">
    <div class="row">
        <div class="col-xs-12 nav-links">
            

    <ul class="nav"><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us" target="_self" class="">About Us</a><ul><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us/eden-story" target="_self" class="">The Eden Story</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us/salon" target="_self" class="">Our Salon</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/about-us/eden-team" target="_self" class="">The Eden Team</a></li></ul></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments" target="_self" class="">Products &amp; Treatments</a><ul><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments/our-products" target="_self" class="">Our Products</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments/our-treatments" target="_self" class="">Our Treatments</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/products-treatments/book-treatment" target="_self" class="">Book a Treatment</a></li></ul></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/connect" target="_self" class="">Connect</a><ul><li class=""><a href="https://edenhealthandbeautyspa.co.uk/connect/contact-us" target="_self" class="">Contact Us</a></li><li class=""><a href="https://edenhealthandbeautyspa.co.uk/connect/eden-newsletter" target="_self" class="">Eden Newsletter</a></li></ul></li></ul>
        </div>
    </div>
</nav>

<header class="header-hero">
    <div class="hero-image" style="background-image:url(/application/files/7115/9555/0831/shelf-candles-towels-teal.jpg);">
        <div class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        

    <h1>Welcome to Cheltenham&rsquo;s<br class="hidden-sm hidden-sm" />
friendliest home beauty salon</h1>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="page-intro">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    

    <p class="lead">You&rsquo;ll find a warm welcome and a comfortable, friendly atmosphere at Eden. We look forward to seeing you very soon.</p>

                </div>
            </div>
        </div>
    </div>
</header>

<main class="main-content">
    

<div class="container"><div class="row"><div class="col-sm-12">    <section class="row"><div class="col-xs-12">

    <script src="https://fast.wistia.com/embed/medias/r86tczxw7d.jsonp" async></script><script src="https://fast.wistia.com/assets/external/E-v1.js" async></script><div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"><div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;"><div class="wistia_embed wistia_async_r86tczxw7d seo=false videoFoam=true" style="height:100%;position:relative;width:100%"><div class="wistia_swatch" style="height:100%;left:0;opacity:0;overflow:hidden;position:absolute;top:0;transition:opacity 200ms;width:100%;"><img src="https://fast.wistia.com/embed/medias/r86tczxw7d/swatch" style="filter:blur(5px);height:100%;object-fit:contain;width:100%;" alt="" aria-hidden="true" onload="this.parentNode.style.opacity=1;" /></div></div></div></div>
</div></section>
</div></div></div>
        <div class="ccm-custom-style-container ccm-custom-style-main-98 vertical-center"
            >

<div class="container"><div class="row"><div class="col-sm-12">    <section class="row"><div class="col-xs-12 col-md-6">

    <h2>An Award Winning Salon</h2>

<p>Winners of the prestigious England&rsquo;s Business Awards. This award is instigated by public nomination and the process involves the business being scrutinised, a voting system, and multiple secret shoppers. Each award was whittled down to 5 finalists. We were so thrilled to even be nominated and found the whole process thrilling with the icing on the cake attending the gala evening and being announced 2019 &lsquo;Best Beauty Salon Gloucestershire&rsquo; winners! Thank you all for your support!</p>

</div><div class="col-xs-12 col-md-6">

    <picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/4715/9546/4314/award-winning.jpg" alt="England’s Business Awards winners 2019" class="ccm-image-block img-responsive bID-95"></picture>
</div></section>
</div></div></div>    </div>
</main>


<footer class="footer-site-footer">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-4">
                <section class="footer-desc">
                    

    <h3>Contact Us</h3>

<ul class="icon-list">
	<li class="phone"><a href="tel:01242528282">01242 528 282</a></li>
	<li class="mobile"><a href="tel:07968802423">07968 802 423</a> (txt only!)</li>
	<li class="place">Home Salon<br />
	Stoke Orchard<br />
	Cheltenham GL52 7SH<br />
	<a href="https://www.edenhealthandbeautyspa.co.uk/about-us/how-to-find-us">Map</a></li>
</ul>

<p><a href="https://www.edenhealthandbeautyspa.co.uk/connect/contact-us">Send us a message</a><br />
<a href="https://www.edenhealthandbeautyspa.co.uk/products-treatments/book-treatment">Book an appointment</a></p>

                </section>
            </div>

            <div class="col-xs-12 col-md-4">
                <section class="footer-contact">
                    

    <h3>Opening Hours</h3>

<p>Monday to Saturday, by appointment.</p>
<!--
<table style="width:100%;">
	<tbody>
		<tr>
			<td>Monday</td>
			<td>By appointment</td>
		</tr>
		<tr>
			<td>Tuesday</td>
			<td>By appointment</td>
		</tr>
		<tr>
			<td>Wednesday</td>
			<td>10:00&ndash;20:00</td>
		</tr>
		<tr>
			<td>Thursday</td>
			<td>09:30&ndash;18:00</td>
		</tr>
		<tr>
			<td>Friday</td>
			<td>09:00&ndash;18:00</td>
		</tr>
		<tr>
			<td>Saturday</td>
			<td>08:30&ndash;16:00</td>
		</tr>
	</tbody>
</table>
-->
                </section>
            </div>

            <div class="col-xs-12 col-md-4">
                <section class="footer-social">
                    

    <h3>Follow Us</h3>



        <div class="ccm-custom-style-container ccm-custom-style-footersocials-81 social-icon"
            >
    <a href="https://www.facebook.com/edenhealthandbeauty/" target="_blank"><svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook-square" class="svg-inline--fa fa-facebook-square fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z"></path></svg></a>
    </div>


        <div class="ccm-custom-style-container ccm-custom-style-footersocials-82 social-icon"
            >
    <a href="https://www.instagram.com/edenhealthandbeauty/" target="_blank"><svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="instagram-square" class="svg-inline--fa fa-instagram-square fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M224,202.66A53.34,53.34,0,1,0,277.36,256,53.38,53.38,0,0,0,224,202.66Zm124.71-41a54,54,0,0,0-30.41-30.41c-21-8.29-71-6.43-94.3-6.43s-73.25-1.93-94.31,6.43a54,54,0,0,0-30.41,30.41c-8.28,21-6.43,71.05-6.43,94.33S91,329.26,99.32,350.33a54,54,0,0,0,30.41,30.41c21,8.29,71,6.43,94.31,6.43s73.24,1.93,94.3-6.43a54,54,0,0,0,30.41-30.41c8.35-21,6.43-71.05,6.43-94.33S357.1,182.74,348.75,161.67ZM224,338a82,82,0,1,1,82-82A81.9,81.9,0,0,1,224,338Zm85.38-148.3a19.14,19.14,0,1,1,19.13-19.14A19.1,19.1,0,0,1,309.42,189.74ZM400,32H48A48,48,0,0,0,0,80V432a48,48,0,0,0,48,48H400a48,48,0,0,0,48-48V80A48,48,0,0,0,400,32ZM382.88,322c-1.29,25.63-7.14,48.34-25.85,67s-41.4,24.63-67,25.85c-26.41,1.49-105.59,1.49-132,0-25.63-1.29-48.26-7.15-67-25.85s-24.63-41.42-25.85-67c-1.49-26.42-1.49-105.61,0-132,1.29-25.63,7.07-48.34,25.85-67s41.47-24.56,67-25.78c26.41-1.49,105.59-1.49,132,0,25.63,1.29,48.33,7.15,67,25.85s24.63,41.42,25.85,67.05C384.37,216.44,384.37,295.56,382.88,322Z"></path></svg></a>
    </div>


    <h3>The Eden Newsletter</h3>

<p>Get the latest news and offers hot off the press, <a href="https://www.edenhealthandbeautyspa.co.uk/connect/eden-newsletter">subscribe to the Eden email newsletter!</a></p>

                </section>
            </div>
        </div>
    </div>
</footer>

<footer class="site-footer-smallprint">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <section class="footer-legals">
                    

    <p>&copy; 2023 Eden Health And Beauty. All rights reserved | <a href="https://www.edenhealthandbeautyspa.co.uk/privacy">Privacy</a> | <a href="http://gooberlicious.co.uk" target="_blank">This is Gooberlicious</a></p>

                </section>
            </div>
        </div>
    </div>
</footer>

<nav class="top-link"><a href="#top" title="Return to top"><svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"/></svg></a></nav>


</div>

<script type="text/javascript" src="/application/files/cache/js/950c390d49a9b5b6864b59145beb9eaa3e956420.js?ccm_nocache=d846f33d9148b37e63b22ff9a7339155be77a7f9" data-source="/concrete/js/picturefill.js?ccm_nocache=d846f33d9148b37e63b22ff9a7339155be77a7f9 /concrete/blocks/image/view.js?ccm_nocache=d846f33d9148b37e63b22ff9a7339155be77a7f9"></script>
<script src="/application/themes/eden/vendor/bootstrap-3.4.1-dist/js/bootstrap.min.js"></script>
<script src="/application/themes/eden/js/utils.js" type="text/javascript"></script>

</body>
</html>
